package ConferenceSystem;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBin.ConferencePageFactory;
import PageBin.PaymentPageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	WebDriver driver;
	ConferencePageFactory objConf;
	PaymentPageFactory objPymt;
	String projectLoc = System.getProperty("user.dir");

	/*************************************************************************************
	 - Method Name		:	user_is_on_registration_page()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/
	
	@Given("^User is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", projectLoc + "\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objConf = new ConferencePageFactory(driver);
		driver.get(projectLoc + "\\lib\\views\\ConferenceRegistartion.html");
	}
	
	/*************************************************************************************
	 - Method Name		:	check_the_title_of_the_registration_page()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@Then("^Check the title of the registration page$")
	public void check_the_title_of_the_registration_page() throws Throwable {
		String title = driver.getTitle();
		if (title.contentEquals("Conference Registartion")) {
			System.out.println("****Title Matched****");
		} else {
			System.out.println("****Title Not Mached****");
		}
		Thread.sleep(1000);
		driver.close();
	}

	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_first_name_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/
	
	@When("^User leaves the first name empty$")
	public void user_leaves_the_first_name_empty() throws Throwable {
		objConf.setFirstname("");
		Thread.sleep(1000);
	}

	
	/*************************************************************************************
	 - Method Name		:	clicks_Next_button()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/
	
	@When("^clicks Next button$")
	public void clicks_Next_button() throws Throwable {
		objConf.setNextBtn();
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	shows_the_alert_message()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@Then("^Shows the alert message$")
	public void shows_the_alert_message() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String alertMsg = alert.getText();
		Thread.sleep(1000);
		System.out.println("****" + alertMsg + "****");
		alert.accept();
		driver.close();
	}

	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_last_name_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/
	
	@When("^User leaves the last name empty$")
	public void user_leaves_the_last_name_empty() throws Throwable {
		objConf.setFirstname("Shubham");
		Thread.sleep(1000);
		objConf.setLastname("");
		Thread.sleep(1000);
	}

	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_email_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/
	
	@When("^User leaves the email empty$")
	public void user_leaves_the_email_empty() throws Throwable {
		objConf.setFirstname("Shubham");
		Thread.sleep(1000);
		objConf.setLastname("Kumar");
		Thread.sleep(1000);
		objConf.setEmail("");
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_contact_no_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@When("^User leaves the contact no empty$")
	public void user_leaves_the_contact_no_empty() throws Throwable {
		objConf.setFirstname("Shubham");
		Thread.sleep(1000);
		objConf.setLastname("Kumar");
		Thread.sleep(1000);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(1000);
		objConf.setContactno("");
		Thread.sleep(1000);
	}

	
	/*************************************************************************************
	 - Method Name		:	user_enters_the_invalid_contact()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/
	
	@When("^User enters the invalid contact$")
	public void user_enters_the_invalid_contact() throws Throwable {
		objConf.setFirstname("Shubham");
		Thread.sleep(1000);
		objConf.setLastname("Kumar");
		Thread.sleep(1000);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(1000);
		objConf.setContactno("1245789621");
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_no_of_people_attending_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@When("^User leaves the no of people attending empty$")
	public void user_leaves_the_no_of_people_attending_empty() throws Throwable {
		objConf.setFirstname("Shubham");
		Thread.sleep(1000);
		objConf.setLastname("Kumar");
		Thread.sleep(1000);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(1000);
		objConf.setContactno("7599246005");
		Thread.sleep(1000);
		objConf.setNoOfPeoples("");
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_building_and_room_no_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@When("^User leaves the building and room no empty$")
	public void user_leaves_the_building_and_room_no_empty() throws Throwable {
		objConf.setFirstname("Shubham");
		Thread.sleep(1000);
		objConf.setLastname("Kumar");
		Thread.sleep(1000);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(1000);
		objConf.setContactno("7599246005");
		Thread.sleep(1000);
		objConf.setNoOfPeoples("3");
		Thread.sleep(1000);
		objConf.setBuilding("");
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_area_name_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@When("^User leaves the area name empty$")
	public void user_leaves_the_area_name_empty() throws Throwable {
		objConf.setFirstname("Shubham");
		Thread.sleep(1000);
		objConf.setLastname("Kumar");
		Thread.sleep(1000);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(1000);
		objConf.setContactno("7599246005");
		Thread.sleep(1000);
		objConf.setNoOfPeoples("3");
		Thread.sleep(1000);
		objConf.setBuilding("Devi Indrayani Society");
		Thread.sleep(1000);
		objConf.setArea("");
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_city_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@When("^User leaves the city empty$")
	public void user_leaves_the_city_empty() throws Throwable {
		objConf.setFirstname("Shubham");
		Thread.sleep(1000);
		objConf.setLastname("Kumar");
		Thread.sleep(1000);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(1000);
		objConf.setContactno("7599246005");
		Thread.sleep(1000);
		objConf.setNoOfPeoples("3");
		Thread.sleep(1000);
		objConf.setBuilding("Devi Indrayani Society");
		Thread.sleep(1000);
		objConf.setArea("Talwade");
		Thread.sleep(1000);
		objConf.setCity("Select City");
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_state_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@When("^User leaves the state empty$")
	public void user_leaves_the_state_empty() throws Throwable {
		objConf.setFirstname("Shubham");
		Thread.sleep(1000);
		objConf.setLastname("Kumar");
		Thread.sleep(1000);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(1000);
		objConf.setContactno("7599246005");
		Thread.sleep(1000);
		objConf.setNoOfPeoples("3");
		Thread.sleep(1000);
		objConf.setBuilding("Devi Indrayani Society");
		Thread.sleep(1000);
		objConf.setArea("Talwade");
		Thread.sleep(1000);
		objConf.setCity("Pune");
		Thread.sleep(1000);
		objConf.setState("Select State");
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_membership_type_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@When("^User leaves the membership type empty$")
	public void user_leaves_the_membership_type_empty() throws Throwable {
		objConf.setFirstname("Shubham");
		Thread.sleep(1000);
		objConf.setLastname("Kumar");
		Thread.sleep(1000);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(1000);
		objConf.setContactno("7599246005");
		Thread.sleep(1000);
		objConf.setNoOfPeoples("3");
		Thread.sleep(1000);
		objConf.setBuilding("Devi Indrayani Society");
		Thread.sleep(1000);
		objConf.setArea("Talwade");
		Thread.sleep(1000);
		objConf.setCity("Pune");
		Thread.sleep(1000);
		objConf.setState("Maharashtra");
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	user_gives_all_valid_data()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@When("^User gives all valid data$")
	public void user_gives_all_valid_data() throws Throwable {
		objConf.setFirstname("Shubham");
		Thread.sleep(1000);
		objConf.setLastname("Kumar");
		Thread.sleep(1000);
		objConf.setEmail("skg11786@gmail.com");
		Thread.sleep(1000);
		objConf.setContactno("7599246005");
		Thread.sleep(1000);
		objConf.setNoOfPeoples("3");
		Thread.sleep(1000);
		objConf.setBuilding("Devi Indrayani Society");
		Thread.sleep(1000);
		objConf.setArea("Talwade");
		Thread.sleep(1000);
		objConf.setCity("Pune");
		Thread.sleep(1000);
		objConf.setState("Maharashtra");
		Thread.sleep(1000);
		objConf.setMemberStatus();
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	shows_the_alert_message_and_navigate_to_payment_page()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@Then("^Shows the alert message and navigate to payment page$")
	public void shows_the_alert_message_and_navigate_to_payment_page() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String alertMsg = alert.getText();
		Thread.sleep(1000);
		System.out.println("****" + alertMsg + "****");
		alert.accept();

		driver.navigate().to(projectLoc + "\\lib\\views\\PaymentDetails.html");
		Thread.sleep(1000);
		driver.close();
	}
	
	
	/*************************************************************************************
	 - Method Name		:	user_is_on_payment_page()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@Given("^User is on payment page$")
	public void user_is_on_payment_page() throws Throwable {
		String projectLoc = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLoc + "\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objPymt = new PaymentPageFactory(driver);
		driver.get(projectLoc + "\\lib\\views\\PaymentDetails.html");
	}
	
	
	/*************************************************************************************
	 - Method Name		:	check_the_title_of_the_payment_page()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@Then("^Check the title of the payment page$")
	public void check_the_title_of_the_payment_page() throws Throwable {
		String title = driver.getTitle();
		if (title.contentEquals("Payment Details")) {
			System.out.println("****Title Matched****");
		} else {
			System.out.println("****Title Not Mached****");
		}
		Thread.sleep(1000);
		driver.close();
	}
	
	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_card_holder_name_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@When("^User leaves the card holder name empty$")
	public void user_leaves_the_card_holder_name_empty() throws Throwable {
		objPymt.setCardHoldername("");
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	clicks_make_payment_button()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@When("^clicks make payment button$")
	public void clicks_make_payment_button() throws Throwable {
		objPymt.setPaymentbtn();
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_debit_card_no_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@When("^User leaves the debit card no empty$")
	public void user_leaves_the_debit_card_no_empty() throws Throwable {
		objPymt.setCardHoldername("Shubham Kumar");
		Thread.sleep(1000);
		objPymt.setDebitCardNo("");
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_cvv_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@When("^User leaves the cvv empty$")
	public void user_leaves_the_cvv_empty() throws Throwable {
		objPymt.setCardHoldername("Shubham Kumar");
		Thread.sleep(1000);
		objPymt.setDebitCardNo("4567894578459658");
		Thread.sleep(1000);
		objPymt.setCvv("");
		Thread.sleep(1000);
	}

	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_expiration_month_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/
	
	@When("^User leaves the expiration month empty$")
	public void user_leaves_the_expiration_month_empty() throws Throwable {
		objPymt.setCardHoldername("Shubham Kumar");
		Thread.sleep(1000);
		objPymt.setDebitCardNo("4567894578459658");
		Thread.sleep(1000);
		objPymt.setCvv("786");
		Thread.sleep(1000);
		objPymt.setExpMonth("");
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	user_leaves_the_expiration_year_empty()
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@When("^User leaves the expiration year empty$")
	public void user_leaves_the_expiration_year_empty() throws Throwable {
		objPymt.setCardHoldername("Shubham Kumar");
		Thread.sleep(1000);
		objPymt.setDebitCardNo("4567894578459658");
		Thread.sleep(1000);
		objPymt.setCvv("786");
		Thread.sleep(1000);
		objPymt.setExpMonth("11");
		Thread.sleep(1000);
		objPymt.setExpYear("");
		Thread.sleep(1000);
	}
	
	
	/*************************************************************************************
	 - Method Name		:	user_gives_all_the_valid_data() 
	 - Input Parameter	:	none
	 - Return Type		:	void
	 - Throws			:	Throwable
	 - Author			: 	Shubham Kumar
	 - Date				:	27-03-2019
	 **************************************************************************************/

	@When("^User gives all the valid data$")
	public void user_gives_all_the_valid_data() throws Throwable {
		objPymt.setCardHoldername("Shubham Kumar");
		Thread.sleep(1000);
		objPymt.setDebitCardNo("4567894578459658");
		Thread.sleep(1000);
		objPymt.setCvv("786");
		Thread.sleep(1000);
		objPymt.setExpMonth("11");
		Thread.sleep(1000);
		objPymt.setExpYear("2025");
		Thread.sleep(1000);
	}
}
