package second;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
	private static String url = null;
	private static String usn = null;
	private static String pswd = null;
	private static String driver = null;
	private static Connection conn = null;

	public static Connection getCon() throws SQLException, IOException {
		Properties myProps = getProps();
		url = myProps.getProperty("dburl");
		usn = myProps.getProperty("dbusn");
		pswd = myProps.getProperty("dbpswd");

		if (conn == null) {
			conn = DriverManager.getConnection(url, usn, pswd);
		}
		return conn;
	}

	public static Properties getProps() throws IOException {
		Properties dbProps = new Properties();
		FileReader fr = new FileReader("DBInfo.properties");

		dbProps.load(fr);
		return dbProps;
	}
}
