package sixth;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import second.DBUtil;

public class TransactionDemo {
	public static void main(String[] args) {
		Connection conn = null;
		try {
			conn = DBUtil.getCon();
			conn.setAutoCommit(false);
			String update1 = "UPDATE emp1 SET emp_name = 'Vishal' WHERE emp_id = 111";
			String update2 = "UPDATE emp1 SET emp_sal = 4000 WHERE emp_id = 222";		
			Statement stmt = conn.createStatement();
			stmt.addBatch(update1);
			stmt.addBatch(update2);
			
			int[] arr = stmt.executeBatch();
			conn.commit();
			System.out.println("Updated Success...");
		} catch (SQLException | IOException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} 
		

	}

}
