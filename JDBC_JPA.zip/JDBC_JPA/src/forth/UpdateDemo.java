package forth;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import second.DBUtil;

public class UpdateDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter empId: ");
		int eid = sc.nextInt();
		
		System.out.println("Enter salary: ");
		double sal = sc.nextDouble();
		
		try {
			Connection conn = DBUtil.getCon();
			String updateQuery = "UPDATE emp1 set emp_sal=? where emp_id=?";
			PreparedStatement pstmt = conn.prepareStatement(updateQuery);
			pstmt.setDouble(1, sal);
			pstmt.setInt(2, eid);
			
			int data = pstmt.executeUpdate();
			System.out.println("Data Updated");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}

}
