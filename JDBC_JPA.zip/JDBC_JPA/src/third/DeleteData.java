package third;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import second.DBUtil;

public class DeleteData {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter empId: ");
		int eid = sc.nextInt();
		
		try {
			Connection conn = DBUtil.getCon();
			String deleteQuery = "DELETE FROM emp1 where emp_id = ?";
			PreparedStatement pstmt = conn.prepareStatement(deleteQuery);
			pstmt.setInt(1, eid);
			
			int data = pstmt.executeUpdate();
			System.out.println("Data deleted");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}

}
