package fifth;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import second.DBUtil;

public class ResultSetMetaDataDemo {

	public static void main(String[] args) {
		try {
			Connection conn = DBUtil.getCon();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM emp1");
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			System.out.println("No of Col: "+ columnCount);
			
			for(int i=1;i<=columnCount;i++) {
				System.out.println(i+". Column Name: "+ rsmd.getColumnName(i));
			}
			
			for(int i=1;i<=columnCount;i++) {
				System.out.println(i+". Column Type: "+ rsmd.getColumnType(i));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
