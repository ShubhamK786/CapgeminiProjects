package first;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EmpDemo {

	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt = null;
//		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "Capgemini123");
			stmt = conn.createStatement();
			rs = stmt.executeQuery("SELECT * FROM emp1");
			System.out.println("before Inserted...\n");
			System.out.println("Id\t\tName\t\tSalary\t\tDOJ");
			System.out.println("--------------------------------------------------------------------");
			while (rs.next()) {
				System.out.println(rs.getInt("emp_id") + "\t\t" + rs.getString("emp_name") + "\t\t"
						+ rs.getInt("emp_sal") + "\t\t" + rs.getDate("emp_doj"));
			}

//			pstmt = conn.prepareStatement("INSERT INTO emp1 VALUES(?,?,?,?)");
//			pstmt.setInt(1, 444);
//			pstmt.setString(2, "Brajesh");
//			pstmt.setInt(3, 4000);
//			pstmt.setDate(4, java.sql.Date.valueOf("2002-09-04"));
//			
//			int exec = pstmt.executeUpdate();
//			System.out.println(exec + " row is updated.\n");
//			System.out.println("After Inserted...\n");
//			
//			rs = stmt.executeQuery("SELECT * FROM emp1");
//			System.out.println("Id\t\tName\t\t\tSalary\t\tDOJ");
//			System.out.println("--------------------------------------------------------------------");
//			while (rs.next()) {
//				System.out.println(rs.getInt("emp_id") + "\t\t" + rs.getString("emp_name") + "\t\t"
//						+ rs.getInt("emp_sal") + "\t\t" + rs.getDate("emp_doj"));
//			}
			
			rs.close();
//			pstmt.close();
			stmt.close();
			conn.close();

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
}
