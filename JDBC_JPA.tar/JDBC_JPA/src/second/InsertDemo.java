package second;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter empId: ");
		int eid = sc.nextInt();
		
		System.out.println("Enter EmpName: ");
		sc.nextLine();
		String ename = sc.nextLine();
		
		System.out.println("Enter salary: ");
		double sal = sc.nextDouble();
		
		try {
			Connection conn = DBUtil.getCon();
			String insertQuery = "INSERT INTO emp1(emp_id, emp_name, emp_sal) values(?,?,?)";
			PreparedStatement pstmt = conn.prepareStatement(insertQuery);
			pstmt.setInt(1, eid);
			pstmt.setString(2, ename);
			pstmt.setDouble(3, sal);
			int data = pstmt.executeUpdate();
			System.out.println("Data Inserted...");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
