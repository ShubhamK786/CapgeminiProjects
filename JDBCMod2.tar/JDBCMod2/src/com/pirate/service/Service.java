package com.pirate.service;

public class Service {
	
}
