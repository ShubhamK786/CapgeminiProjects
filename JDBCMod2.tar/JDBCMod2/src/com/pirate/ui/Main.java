package com.pirate.ui;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.pirate.util.DBUtil;


public class Main {

	public static void main(String[] args) {
		String delQuery = "delete from list1 where id in (select id from list2)";
		
		try {
			Connection conn = DBUtil.getCon();
			Statement stmt = conn.createStatement();
			int data = stmt.executeUpdate(delQuery);
			System.out.println("deleted...");
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
