package com.pirate.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {
	private static Connection conn = null;
	private static String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private static String usn = "system";
	private static String pswd = "Capgemini123";
	private static String driver = "oracle.jdbc.driver.OracleDriver";
	
	

	public DBUtil() {
		super();
	}



	public static Connection getCon() throws SQLException, IOException {
		if (conn == null) {
			conn = DriverManager.getConnection(url, usn, pswd);
		}
		return conn;
	}
}
