package com.capgemini.takehome.service;

import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.exception.ProductCodeNotFoundException;

public class ProductService implements IProductService {
	
	IProductDAO productDAO;
	
	public ProductService(IProductDAO productDAO) {
		super();
		this.productDAO = productDAO;
	}
	
	/**************************************************************************
	 * Method Name		:	total(int productId, int productQuantity)
	 * Input Parameter	:	int productId, int productQuantity
	 * Return Type		:	double
	 * Author			:	Shubham Kumar
	 * Date				: 	12/02/2019		
	 * Description		:	to calculate the total price of given product.
	 * @throws ProductCodeNotFoundException 
	 ***************************************************************************/

	@Override
	public double total(int productId, int productQuantity) throws ProductCodeNotFoundException {
		
		double productPrice = productDAO.findPrice(productId);
		
		double totalPrice = productPrice * productQuantity;
		
		return totalPrice;
	}
	
}
