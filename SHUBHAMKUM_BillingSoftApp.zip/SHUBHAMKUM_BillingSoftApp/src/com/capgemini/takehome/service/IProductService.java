package com.capgemini.takehome.service;

import com.capgemini.takehome.exception.ProductCodeNotFoundException;

public interface IProductService {

	double total(int productId, int productQuantity) throws ProductCodeNotFoundException;

}