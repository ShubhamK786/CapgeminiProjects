package com.capgemini.takehome.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.exception.ProductCodeNotFoundException;
import com.capgemini.takehome.service.ProductService;

class MethodTest {

	@Test
	void priceTesting() throws ProductCodeNotFoundException {
		assertEquals(70000, new ProductService(new ProductDAO()).total(1001, 2));
	}
	

}
