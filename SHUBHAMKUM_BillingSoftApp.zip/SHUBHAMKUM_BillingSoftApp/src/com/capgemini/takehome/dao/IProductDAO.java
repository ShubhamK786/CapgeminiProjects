package com.capgemini.takehome.dao;

import com.capgemini.takehome.exception.ProductCodeNotFoundException;

public interface IProductDAO {

	double findPrice(int productId) throws ProductCodeNotFoundException;

}