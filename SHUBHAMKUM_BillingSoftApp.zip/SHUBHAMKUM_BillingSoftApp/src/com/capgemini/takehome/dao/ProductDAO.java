package com.capgemini.takehome.dao;

import com.capgemini.takehome.exception.ProductCodeNotFoundException;
import com.capgemini.takehome.util.CollectionUtil;

public class ProductDAO implements IProductDAO {
	
	CollectionUtil collectionUtil = new CollectionUtil();
	
	/**************************************************************************
	 * Method Name		:	findPrice(int productId) throws ProductCodeNotFoundException
	 * Input Parameter	:	int productId
	 * Return Type		:	double
	 * tHROWS			: 	ProductCodeNotFoundException
	 * Author			:	Shubham Kumar
	 * Date				: 	12/02/2019		
	 * Description		:	to calculate the total price of given product.
	 ***************************************************************************/
	
	@Override
	public double findPrice(int productId) throws ProductCodeNotFoundException {
	
		return collectionUtil.findProductId(productId);
	}
	
	
	
}
