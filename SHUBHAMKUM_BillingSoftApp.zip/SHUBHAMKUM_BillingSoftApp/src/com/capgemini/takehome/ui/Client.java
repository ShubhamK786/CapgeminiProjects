package com.capgemini.takehome.ui;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.exception.ProductCodeNotFoundException;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;

public class Client {

	static IProductService productService = new ProductService(new ProductDAO());
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter Product Id: ");
		int productId = scanner.nextInt();
		if (isValidProductID(productId)) {
			System.out.println("Enter quantity: ");
			int productQuantity = scanner.nextInt();
			if (isValidProductQuantity(productQuantity)) {
				 try {
					double totalPrice = productService.total(productId,productQuantity);
					System.out.println(totalPrice);
				} catch (ProductCodeNotFoundException e) {
					System.out.println("Sorry! The Product Code "+ productId +" is not available.");
				}
			} else {
				System.out.println("Quantity should not be less than or equal to zero.");
			}
		} else {
			System.out.println("Id is not Valid.");
		}

	}
	
	
	/**************************************************************************
	 * Method Name		:	isValidProductId
	 * Input Parameter	:	int productId
	 * Return Type		:	boolean
	 * Author			:	Shubham Kumar
	 * Date				: 	12/02/2019		
	 * Description		:	To check weather a given productId is valid or not.
	 ***************************************************************************/

	public static boolean isValidProductID(int productId) {
		String id = "" + productId;
		String numPattern = "^\\d{4}$";
		Pattern pattern = Pattern.compile(numPattern);
		Matcher matcher = pattern.matcher(id);
		return matcher.matches();
	}
	
	
	/***********************************************************************************
	 * Method Name		:	isValidProductQuantity
	 * Input Parameter	:	int productQuantity
	 * Return Type		:	boolean
	 * Author			:	Shubham Kumar
	 * Date				: 	12/02/2019		
	 * Description		:	To check weather a given product quantity is valid or not.
	 ***********************************************************************************/

	public static boolean isValidProductQuantity(int productQuantity) {
		
		String quantity = "" + productQuantity;
		String numPattern = "^[1-9]([0-9].)?$";
		Pattern pattern = Pattern.compile(numPattern);
		Matcher matcher = pattern.matcher(quantity);
		return matcher.matches();
	}
}
