package com.pirate.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	
	private static Connection conn = null;
	private static String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private static String user = "system";
	private static String pswd = "Capgemini123";
	private static String driver = "oracle.jdbc.driver.OracleDriver";
	
	public static Connection getConn() throws SQLException, IOException {
		
		if(conn==null) {
			try {
				Class.forName(driver);
				conn = DriverManager.getConnection(url, user, pswd);
			} catch (ClassNotFoundException e) {
				System.out.println(e);
				e.printStackTrace();
			}
		}
		return conn;
	}

}
