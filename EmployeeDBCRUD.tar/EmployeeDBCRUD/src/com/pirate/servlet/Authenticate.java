package com.pirate.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pirate.bean.Employee;
import com.pirate.dao.EmpDAO;

@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String email = request.getParameter("email");
		String password = request.getParameter("pswd");
	
		Employee emp = EmpDAO.loginUser(email);
		if(password.equals(emp.getPswd())) {
			HttpSession session=request.getSession();  
	        session.setAttribute("name",emp.getName());  
	        session.setAttribute("id",emp.getId());
	        System.out.println(emp.getId());
			request.getRequestDispatcher("WEB-INF/pages/admin.jsp").forward(request, response);
		}
		else {
			request.setAttribute("msg", "Invalid Email or Pasword.");
			request.getRequestDispatcher("WEB-INF/pages/login.jsp").forward(request, response);
		}

	}

}
