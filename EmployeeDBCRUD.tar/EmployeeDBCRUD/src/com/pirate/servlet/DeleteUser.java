package com.pirate.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pirate.dao.EmpDAO;

@WebServlet("/deleteUser")
public class DeleteUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String sid = request.getParameter("id");
		int id = Integer.parseInt(sid);
		int pageId = 1;
		int temp1 = id/5;
		int temp2 = id%5;
		if(temp2==0) {
			pageId = temp1;
		}
		else {
			pageId = temp1+1;
		}
		int status = EmpDAO.deleteUser(id);
		request.getRequestDispatcher("showUsers?page="+pageId).include(request, response);
		out.print("<br><center>User Deleted.</center></br>");
	}

}
