package com.pirate.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pirate.bean.Employee;
import com.pirate.dao.EmpDAO;

@WebServlet("/updateUser")
public class UpdateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String sid = request.getParameter("id");
		int id = Integer.parseInt(sid);
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String password = request.getParameter("pswd");

		Employee emp = new Employee();
		emp.setId(id);
		emp.setName(name);
		emp.setEmail(email);
		emp.setPswd(password);
		
		int status = EmpDAO.editUser(emp);
		if(status>0) {
			request.getRequestDispatcher("/WEB-INF/pages/signup.jsp").include(request, response);
			out.println("<br><center>User Updated.</center>");
		}
		else {
			out.print("<br><center>User not updated.</center>");
		}
		
		
	}

}
